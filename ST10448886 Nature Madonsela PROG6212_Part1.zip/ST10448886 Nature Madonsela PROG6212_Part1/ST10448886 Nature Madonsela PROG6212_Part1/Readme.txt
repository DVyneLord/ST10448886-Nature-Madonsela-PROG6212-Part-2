# How to Run CMCS Prototype

## Prerequisites
1. Windows 10 or Windows 11
2. Visual Studio 2022
3. .NET Core SDK installed

## Installation Steps
1. Download/clone the project files
2. Open Visual Studio 2022
3. Open the .sln solution file
4. Build the solution
5. Make sure the JSON packages are installed else it will give you errors

## Running the Application
1. Set startup project to "Plan"
2. Press F5 to run
3. Login window will open

## Testing the Prototype
1. **MainWindow**: Try all three tabs (Sign In, Register, Reset)
2. **Sample Login**: Use "manager@cmcs.com" (pre-filled) or any email
3. **Registration**: Select user type and fill forms
4. **Lecturer Dashboard**: Navigate through My Claims, Submit Claim, Notifications, and Profile tabs
5. **Manager Dashboard**: View statistics, claims grid, and activity panel
6. **Interface Elements**: Click buttons, fill forms, use filters and search boxes

## Important Notes
- This is a visual prototype only
- data is saved in a JSON file no backend was used
- All forms and buttons are for demonstration
- Database connections not implemented yet