﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Plan;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Plan.Tests
{
    /// <summary>
    /// Unit tests for DataManager class
    /// Tests cover user management, claim management, and notification functionality
    /// </summary>
    [TestClass]
    public class DataManagerTests
    {
        // Test file paths - separate from production files
        private const string TestUsersFile = "test_users.json";
        private const string TestClaimsFile = "test_claims.json";
        private const string TestNotificationsFile = "test_notifications.json";

        /// <summary>
        /// Setup method runs before each test
        /// Ensures clean state by deleting any existing test files
        /// </summary>
        [TestInitialize]
        public void Setup()
        {
            CleanupTestFiles();
        }

        /// <summary>
        /// Cleanup method runs after each test
        /// Removes test files to prevent pollution between tests
        /// </summary>
        [TestCleanup]
        public void Cleanup()
        {
            CleanupTestFiles();
        }

        private void CleanupTestFiles()
        {
            if (File.Exists(TestUsersFile))
                File.Delete(TestUsersFile);
            if (File.Exists(TestClaimsFile))
                File.Delete(TestClaimsFile);
            if (File.Exists(TestNotificationsFile))
                File.Delete(TestNotificationsFile);
        }

        #region User Management Tests

        /// <summary>
        /// Test: Adding users to system and loading them back
        /// Expected: All user data should be preserved correctly
        /// </summary>
        [TestMethod]
        public void Test_AddAndLoadUsers_ShouldSaveAndRetrieveCorrectly()
        {
            // Arrange - Create test users
            var users = new List<UserInfo>
            {
                new UserInfo
                {
                    Email = "lecturer@test.com",
                    FullName = "Dr. John Smith",
                    UserType = "Lecturer",
                    IsActive = true,
                    Department = "Computer Science"
                },
                new UserInfo
                {
                    Email = "manager@test.com",
                    FullName = "Prof. Jane Doe",
                    UserType = "Academic Manager",
                    IsActive = true,
                    Department = "Management"
                }
            };

            // Act - Save and load users
            DataManager.SaveUsers(users);
            var loadedUsers = DataManager.LoadUsers();

            // Assert - Verify data integrity
            Assert.IsNotNull(loadedUsers, "Loaded users should not be null");
            Assert.AreEqual(2, loadedUsers.Count, "Should load exactly 2 users");
            Assert.AreEqual("lecturer@test.com", loadedUsers[0].Email, "First user email should match");
            Assert.AreEqual("Dr. John Smith", loadedUsers[0].FullName, "First user name should match");
            Assert.AreEqual("Lecturer", loadedUsers[0].UserType, "First user type should match");
        }

        /// <summary>
        /// Test: Retrieving a specific user by email
        /// Expected: Should return correct user or null if not found
        /// </summary>
        [TestMethod]
        public void Test_GetUserByEmail_ShouldReturnCorrectUser()
        {
            // Arrange
            var users = new List<UserInfo>
            {
                new UserInfo
                {
                    Email = "lecturer@test.com",
                    FullName = "Dr. Smith",
                    UserType = "Lecturer",
                    IsActive = true
                }
            };
            DataManager.SaveUsers(users);

            // Act
            var user = DataManager.GetUser("lecturer@test.com");
            var nonExistentUser = DataManager.GetUser("notfound@test.com");

            // Assert
            Assert.IsNotNull(user, "User should be found");
            Assert.AreEqual("Dr. Smith", user.FullName, "User name should match");
            Assert.IsNull(nonExistentUser, "Non-existent user should return null");
        }

        /// <summary>
        /// Test: Email lookup should be case-insensitive
        /// Expected: Should find user regardless of email case
        /// </summary>
        [TestMethod]
        public void Test_GetUserByEmail_ShouldBeCaseInsensitive()
        {
            // Arrange
            var users = new List<UserInfo>
            {
                new UserInfo
                {
                    Email = "Lecturer@Test.COM",
                    FullName = "Dr. Smith",
                    UserType = "Lecturer",
                    IsActive = true
                }
            };
            DataManager.SaveUsers(users);

            // Act
            var user1 = DataManager.GetUser("lecturer@test.com");
            var user2 = DataManager.GetUser("LECTURER@TEST.COM");
            var user3 = DataManager.GetUser("LeCtuReR@TeSt.CoM");

            // Assert
            Assert.IsNotNull(user1, "Should find user with lowercase email");
            Assert.IsNotNull(user2, "Should find user with uppercase email");
            Assert.IsNotNull(user3, "Should find user with mixed case email");
            Assert.AreEqual(user1.FullName, user2.FullName, "All variations should return same user");
        }

        /// <summary>
        /// Test: Getting all academic managers from user list
        /// Expected: Should return only active academic managers
        /// </summary>
        [TestMethod]
        public void Test_GetAcademicManagers_ShouldReturnOnlyManagers()
        {
            // Arrange
            var users = new List<UserInfo>
            {
                new UserInfo
                {
                    Email = "lecturer1@test.com",
                    FullName = "Dr. Smith",
                    UserType = "Lecturer",
                    IsActive = true
                },
                new UserInfo
                {
                    Email = "manager1@test.com",
                    FullName = "Prof. Johnson",
                    UserType = "Academic Manager",
                    IsActive = true
                },
                new UserInfo
                {
                    Email = "manager2@test.com",
                    FullName = "Dr. Williams",
                    UserType = "Academic Manager",
                    IsActive = false // Inactive
                },
                new UserInfo
                {
                    Email = "manager3@test.com",
                    FullName = "Prof. Brown",
                    UserType = "Academic Manager",
                    IsActive = true
                }
            };
            DataManager.SaveUsers(users);

            // Act
            var managers = DataManager.GetAcademicManagers();

            // Assert
            Assert.IsNotNull(managers, "Managers list should not be null");
            Assert.AreEqual(2, managers.Count, "Should return only 2 active managers");
            Assert.IsTrue(managers.All(m => m.UserType == "Academic Manager"),
                "All returned users should be Academic Managers");
            Assert.IsTrue(managers.All(m => m.IsActive),
                "All returned managers should be active");
        }

        #endregion

        #region Claim Management Tests

        /// <summary>
        /// Test: Adding a new claim to the system
        /// Expected: Claim should be saved with auto-generated ID
        /// </summary>
        [TestMethod]
        public void Test_AddClaim_ShouldGenerateClaimIdAndSave()
        {
            // Arrange
            var claim = new ClaimData
            {
                LecturerEmail = "lecturer@test.com",
                LecturerName = "Dr. Smith",
                AssignedManagerEmail = "manager@test.com",
                Hours = 15,
                HourlyRate = 350,
                TotalAmount = 5250,
                Status = "Pending Review",
                Description = "Teaching hours for May 2024"
            };

            // Act
            string claimId = DataManager.AddClaim(claim);
            var loadedClaims = DataManager.LoadClaims();

            // Assert
            Assert.IsNotNull(claimId, "Claim ID should not be null");
            Assert.IsTrue(claimId.StartsWith("C"), "Claim ID should start with 'C'");
            Assert.AreEqual(1, loadedClaims.Count, "Should have exactly 1 claim");
            Assert.AreEqual(claimId, loadedClaims[0].ClaimId, "Saved claim should have correct ID");
            Assert.AreEqual(5250, loadedClaims[0].TotalAmount, "Total amount should match");
        }

        /// <summary>
        /// Test: Auto-increment of claim numbers
        /// Expected: Each new claim should have unique incrementing number
        /// </summary>
        [TestMethod]
        public void Test_AddMultipleClaims_ShouldAutoIncrementClaimNumbers()
        {
            // Arrange & Act
            var claimId1 = DataManager.AddClaim(new ClaimData
            {
                LecturerEmail = "lecturer@test.com",
                LecturerName = "Dr. Smith",
                Hours = 10,
                HourlyRate = 300,
                TotalAmount = 3000
            });

            var claimId2 = DataManager.AddClaim(new ClaimData
            {
                LecturerEmail = "lecturer@test.com",
                LecturerName = "Dr. Smith",
                Hours = 20,
                HourlyRate = 300,
                TotalAmount = 6000
            });

            var claimId3 = DataManager.AddClaim(new ClaimData
            {
                LecturerEmail = "lecturer2@test.com",
                LecturerName = "Prof. Jones",
                Hours = 15,
                HourlyRate = 400,
                TotalAmount = 6000
            });

            // Assert
            Assert.AreNotEqual(claimId1, claimId2, "Claim IDs should be unique");
            Assert.AreNotEqual(claimId2, claimId3, "Claim IDs should be unique");
            Assert.AreNotEqual(claimId1, claimId3, "Claim IDs should be unique");

            var claims = DataManager.LoadClaims();
            Assert.AreEqual(3, claims.Count, "Should have 3 claims");
        }

        /// <summary>
        /// Test: Updating an existing claim
        /// Expected: Claim data should be updated, LastUpdated should change
        /// </summary>
        [TestMethod]
        public void Test_UpdateClaim_ShouldModifyExistingClaim()
        {
            // Arrange
            var claim = new ClaimData
            {
                LecturerEmail = "lecturer@test.com",
                LecturerName = "Dr. Smith",
                Hours = 10,
                HourlyRate = 300,
                TotalAmount = 3000,
                Status = "Draft"
            };
            string claimId = DataManager.AddClaim(claim);
            var originalClaims = DataManager.LoadClaims();
            var originalClaim = originalClaims.First();

            System.Threading.Thread.Sleep(100); // Small delay to ensure timestamp changes

            // Act
            originalClaim.Status = "Pending Review";
            originalClaim.Hours = 15;
            originalClaim.TotalAmount = 4500;
            DataManager.UpdateClaim(originalClaim);

            var updatedClaims = DataManager.LoadClaims();
            var updatedClaim = updatedClaims.First();

            // Assert
            Assert.AreEqual(1, updatedClaims.Count, "Should still have only 1 claim");
            Assert.AreEqual("Pending Review", updatedClaim.Status, "Status should be updated");
            Assert.AreEqual(15, updatedClaim.Hours, "Hours should be updated");
            Assert.AreEqual(4500, updatedClaim.TotalAmount, "Total amount should be updated");
            Assert.IsTrue(updatedClaim.LastUpdated > originalClaim.SubmitDate,
                "LastUpdated should be more recent");
        }

        /// <summary>
        /// Test: Deleting a claim from the system
        /// Expected: Claim should be completely removed
        /// </summary>
        [TestMethod]
        public void Test_DeleteClaim_ShouldRemoveClaimCompletely()
        {
            // Arrange
            var claim1 = new ClaimData
            {
                LecturerEmail = "lecturer@test.com",
                LecturerName = "Dr. Smith",
                Hours = 10,
                HourlyRate = 300,
                TotalAmount = 3000
            };
            var claim2 = new ClaimData
            {
                LecturerEmail = "lecturer@test.com",
                LecturerName = "Dr. Smith",
                Hours = 20,
                HourlyRate = 300,
                TotalAmount = 6000
            };

            string claimId1 = DataManager.AddClaim(claim1);
            string claimId2 = DataManager.AddClaim(claim2);

            // Act
            DataManager.DeleteClaim(claimId1);
            var remainingClaims = DataManager.LoadClaims();

            // Assert
            Assert.AreEqual(1, remainingClaims.Count, "Should have 1 claim remaining");
            Assert.AreEqual(claimId2, remainingClaims[0].ClaimId, "Remaining claim should be claim2");
            Assert.IsNull(remainingClaims.FirstOrDefault(c => c.ClaimId == claimId1),
                "Deleted claim should not exist");
        }

        /// <summary>
        /// Test: Getting claims by lecturer email
        /// Expected: Should return only claims for specified lecturer
        /// </summary>
        [TestMethod]
        public void Test_GetClaimsByLecturer_ShouldReturnCorrectClaims()
        {
            // Arrange
            DataManager.AddClaim(new ClaimData
            {
                LecturerEmail = "lecturer1@test.com",
                LecturerName = "Dr. Smith",
                Hours = 10,
                HourlyRate = 300,
                TotalAmount = 3000
            });

            DataManager.AddClaim(new ClaimData
            {
                LecturerEmail = "lecturer1@test.com",
                LecturerName = "Dr. Smith",
                Hours = 15,
                HourlyRate = 300,
                TotalAmount = 4500
            });

            DataManager.AddClaim(new ClaimData
            {
                LecturerEmail = "lecturer2@test.com",
                LecturerName = "Prof. Jones",
                Hours = 20,
                HourlyRate = 400,
                TotalAmount = 8000
            });

            // Act
            var lecturer1Claims = DataManager.GetClaimsByLecturer("lecturer1@test.com");
            var lecturer2Claims = DataManager.GetClaimsByLecturer("lecturer2@test.com");

            // Assert
            Assert.AreEqual(2, lecturer1Claims.Count, "Lecturer 1 should have 2 claims");
            Assert.AreEqual(1, lecturer2Claims.Count, "Lecturer 2 should have 1 claim");
            Assert.IsTrue(lecturer1Claims.All(c => c.LecturerEmail == "lecturer1@test.com"),
                "All claims should belong to lecturer1");
        }

        /// <summary>
        /// Test: Getting claims by manager email
        /// Expected: Should return only claims assigned to specified manager
        /// </summary>
        [TestMethod]
        public void Test_GetClaimsByManager_ShouldReturnCorrectClaims()
        {
            // Arrange
            DataManager.AddClaim(new ClaimData
            {
                LecturerEmail = "lecturer1@test.com",
                LecturerName = "Dr. Smith",
                AssignedManagerEmail = "manager1@test.com",
                Hours = 10,
                HourlyRate = 300,
                TotalAmount = 3000
            });

            DataManager.AddClaim(new ClaimData
            {
                LecturerEmail = "lecturer2@test.com",
                LecturerName = "Prof. Jones",
                AssignedManagerEmail = "manager1@test.com",
                Hours = 15,
                HourlyRate = 300,
                TotalAmount = 4500
            });

            DataManager.AddClaim(new ClaimData
            {
                LecturerEmail = "lecturer3@test.com",
                LecturerName = "Dr. Brown",
                AssignedManagerEmail = "manager2@test.com",
                Hours = 20,
                HourlyRate = 400,
                TotalAmount = 8000
            });

            // Act
            var manager1Claims = DataManager.GetClaimsByManager("manager1@test.com");
            var manager2Claims = DataManager.GetClaimsByManager("manager2@test.com");

            // Assert
            Assert.AreEqual(2, manager1Claims.Count, "Manager 1 should have 2 claims");
            Assert.AreEqual(1, manager2Claims.Count, "Manager 2 should have 1 claim");
            Assert.IsTrue(manager1Claims.All(c => c.AssignedManagerEmail == "manager1@test.com"),
                "All claims should be assigned to manager1");
        }

        /// <summary>
        /// Test: Getting manager statistics
        /// Expected: Should calculate correct statistics for manager
        /// </summary>
        [TestMethod]
        public void Test_GetManagerStats_ShouldCalculateCorrectly()
        {
            // Arrange
            string managerEmail = "manager@test.com";

            // Add pending claims
            for (int i = 0; i < 3; i++)
            {
                DataManager.AddClaim(new ClaimData
                {
                    LecturerEmail = $"lecturer{i}@test.com",
                    LecturerName = $"Dr. Lecturer {i}",
                    AssignedManagerEmail = managerEmail,
                    Hours = 10,
                    HourlyRate = 300,
                    TotalAmount = 3000,
                    Status = "Pending Review"
                });
            }

            // Add approved claims
            for (int i = 0; i < 5; i++)
            {
                var claim = new ClaimData
                {
                    LecturerEmail = $"lecturer{i}@test.com",
                    LecturerName = $"Dr. Lecturer {i}",
                    AssignedManagerEmail = managerEmail,
                    Hours = 15,
                    HourlyRate = 400,
                    TotalAmount = 6000,
                    Status = "Approved"
                };
                DataManager.AddClaim(claim);
            }

            // Add rejected claims
            for (int i = 0; i < 2; i++)
            {
                var claim = new ClaimData
                {
                    LecturerEmail = $"lecturer{i}@test.com",
                    LecturerName = $"Dr. Lecturer {i}",
                    AssignedManagerEmail = managerEmail,
                    Hours = 8,
                    HourlyRate = 250,
                    TotalAmount = 2000,
                    Status = "Rejected"
                };
                DataManager.AddClaim(claim);
            }

            // Act
            var stats = DataManager.GetManagerStats(managerEmail);

            // Assert
            Assert.IsNotNull(stats, "Stats should not be null");
            Assert.AreEqual(3, stats.PendingClaims, "Should have 3 pending claims");
            Assert.AreEqual(5, stats.ApprovedThisMonth, "Should have 5 approved claims");
            Assert.AreEqual(2, stats.RejectedThisMonth, "Should have 2 rejected claims");
            Assert.AreEqual(9000, stats.TotalPendingAmount, "Total pending should be 9000 (3 × 3000)");
        }

        #endregion

        #region Notification Tests

        /// <summary>
        /// Test: Creating and retrieving notifications
        /// Expected: Notification should be saved and retrievable by user
        /// </summary>
        [TestMethod]
        public void Test_AddNotification_ShouldSaveCorrectly()
        {
            // Arrange
            var notification = new DataManager.NotificationData
            {
                RecipientEmail = "lecturer@test.com",
                Title = "Claim Approved",
                Message = "Your claim C2024-001 has been approved",
                Type = "Approval",
                RelatedClaimId = "C2024-001"
            };

            // Act
            DataManager.AddNotification(notification);
            var notifications = DataManager.LoadNotifications();

            // Assert
            Assert.AreEqual(1, notifications.Count, "Should have 1 notification");
            Assert.IsNotNull(notifications[0].NotificationId, "Notification ID should be generated");
            Assert.AreEqual("lecturer@test.com", notifications[0].RecipientEmail);
            Assert.AreEqual("Claim Approved", notifications[0].Title);
            Assert.IsFalse(notifications[0].IsRead, "Notification should be unread by default");
        }

        /// <summary>
        /// Test: Getting notifications for specific user
        /// Expected: Should return only user's notifications
        /// </summary>
        [TestMethod]
        public void Test_GetNotificationsByUser_ShouldFilterCorrectly()
        {
            // Arrange
            DataManager.AddNotification(new DataManager.NotificationData
            {
                RecipientEmail = "lecturer1@test.com",
                Title = "Test 1",
                Message = "Message 1",
                Type = "General"
            });

            DataManager.AddNotification(new DataManager.NotificationData
            {
                RecipientEmail = "lecturer1@test.com",
                Title = "Test 2",
                Message = "Message 2",
                Type = "General"
            });

            DataManager.AddNotification(new DataManager.NotificationData
            {
                RecipientEmail = "lecturer2@test.com",
                Title = "Test 3",
                Message = "Message 3",
                Type = "General"
            });

            // Act
            var lecturer1Notifications = DataManager.GetNotificationsByUser("lecturer1@test.com");
            var lecturer2Notifications = DataManager.GetNotificationsByUser("lecturer2@test.com");

            // Assert
            Assert.AreEqual(2, lecturer1Notifications.Count, "Lecturer 1 should have 2 notifications");
            Assert.AreEqual(1, lecturer2Notifications.Count, "Lecturer 2 should have 1 notification");
        }

        /// <summary>
        /// Test: Marking notification as read
        /// Expected: IsRead flag should be updated
        /// </summary>
        [TestMethod]
        public void Test_MarkNotificationAsRead_ShouldUpdateStatus()
        {
            // Arrange
            var notification = new DataManager.NotificationData
            {
                RecipientEmail = "lecturer@test.com",
                Title = "Test",
                Message = "Test message",
                Type = "General"
            };
            DataManager.AddNotification(notification);

            var notifications = DataManager.LoadNotifications();
            string notificationId = notifications[0].NotificationId;

            // Act
            DataManager.MarkNotificationAsRead(notificationId);
            var updatedNotifications = DataManager.LoadNotifications();

            // Assert
            Assert.IsTrue(updatedNotifications[0].IsRead, "Notification should be marked as read");
        }

        /// <summary>
        /// Test: Getting unread notification count
        /// Expected: Should count only unread notifications for user
        /// </summary>
        [TestMethod]
        public void Test_GetUnreadNotificationCount_ShouldCountCorrectly()
        {
            // Arrange
            string userEmail = "lecturer@test.com";

            // Add 3 unread notifications
            for (int i = 0; i < 3; i++)
            {
                DataManager.AddNotification(new DataManager.NotificationData
                {
                    RecipientEmail = userEmail,
                    Title = $"Notification {i}",
                    Message = $"Message {i}",
                    Type = "General"
                });
            }

            // Mark one as read
            var notifications = DataManager.GetNotificationsByUser(userEmail);
            DataManager.MarkNotificationAsRead(notifications[0].NotificationId);

            // Act
            int unreadCount = DataManager.GetUnreadNotificationCount(userEmail);

            // Assert
            Assert.AreEqual(2, unreadCount, "Should have 2 unread notifications");
        }

        /// <summary>
        /// Test: Creating rejection notification
        /// Expected: Should create properly formatted rejection notification
        /// </summary>
        [TestMethod]
        public void Test_CreateRejectionNotification_ShouldFormatCorrectly()
        {
            // Arrange
            string lecturerEmail = "lecturer@test.com";
            string claimId = "C2024-001";
            string reason = "Insufficient documentation provided";
            string managerName = "Prof. Johnson";

            // Act
            DataManager.CreateRejectionNotification(lecturerEmail, claimId, reason, managerName);
            var notifications = DataManager.GetNotificationsByUser(lecturerEmail);

            // Assert
            Assert.AreEqual(1, notifications.Count, "Should have 1 notification");
            Assert.AreEqual("Claim Rejected", notifications[0].Title);
            Assert.IsTrue(notifications[0].Message.Contains(claimId), "Message should contain claim ID");
            Assert.IsTrue(notifications[0].Message.Contains(reason), "Message should contain reason");
            Assert.IsTrue(notifications[0].Message.Contains(managerName), "Message should contain manager name");
            Assert.AreEqual("Rejection", notifications[0].Type);
            Assert.AreEqual(claimId, notifications[0].RelatedClaimId);
        }

        /// <summary>
        /// Test: Deleting a single notification
        /// Expected: Notification should be removed from system
        /// </summary>
        [TestMethod]
        public void Test_DeleteNotification_ShouldRemoveNotification()
        {
            // Arrange
            DataManager.AddNotification(new DataManager.NotificationData
            {
                RecipientEmail = "lecturer@test.com",
                Title = "Test",
                Message = "Test message",
                Type = "General"
            });

            var notifications = DataManager.LoadNotifications();
            string notificationId = notifications[0].NotificationId;

            // Act
            bool result = DataManager.DeleteNotification(notificationId);
            var remainingNotifications = DataManager.LoadNotifications();

            // Assert
            Assert.IsTrue(result, "Delete should return true");
            Assert.AreEqual(0, remainingNotifications.Count, "Should have no notifications remaining");
        }

        /// <summary>
        /// Test: Deleting multiple notifications at once
        /// Expected: All specified notifications should be removed
        /// </summary>
        [TestMethod]
        public void Test_DeleteMultipleNotifications_ShouldRemoveAll()
        {
            // Arrange
            for (int i = 0; i < 5; i++)
            {
                DataManager.AddNotification(new DataManager.NotificationData
                {
                    RecipientEmail = "lecturer@test.com",
                    Title = $"Test {i}",
                    Message = $"Message {i}",
                    Type = "General"
                });
            }

            var notifications = DataManager.LoadNotifications();
            var idsToDelete = notifications.Take(3).Select(n => n.NotificationId).ToList();

            // Act
            bool result = DataManager.DeleteNotifications(idsToDelete);
            var remainingNotifications = DataManager.LoadNotifications();

            // Assert
            Assert.IsTrue(result, "Delete should return true");
            Assert.AreEqual(2, remainingNotifications.Count, "Should have 2 notifications remaining");
        }

        #endregion

        #region Edge Cases and Error Handling Tests

        /// <summary>
        /// Test: Loading users when file doesn't exist
        /// Expected: Should return empty list, not throw exception
        /// </summary>
        [TestMethod]
        public void Test_LoadUsers_WhenFileDoesNotExist_ShouldReturnEmptyList()
        {
            // Act
            var users = DataManager.LoadUsers();

            // Assert
            Assert.IsNotNull(users, "Should return a list, not null");
            Assert.AreEqual(0, users.Count, "Should return empty list");
        }

        /// <summary>
        /// Test: Loading claims when file doesn't exist
        /// Expected: Should return empty list, not throw exception
        /// </summary>
        [TestMethod]
        public void Test_LoadClaims_WhenFileDoesNotExist_ShouldReturnEmptyList()
        {
            // Act
            var claims = DataManager.LoadClaims();

            // Assert
            Assert.IsNotNull(claims, "Should return a list, not null");
            Assert.AreEqual(0, claims.Count, "Should return empty list");
        }

        /// <summary>
        /// Test: Calculating total amount (business logic)
        /// Expected: Should calculate correctly with various inputs
        /// </summary>
        [TestMethod]
        public void Test_CalculateTotalAmount_ShouldBeAccurate()
        {
            // Arrange & Act
            decimal amount1 = 10 * 300.00m;      // 10 hours × R300
            decimal amount2 = 25 * 450.50m;      // 25 hours × R450.50
            decimal amount3 = 8 * 275.75m;       // 8 hours × R275.75

            // Assert
            Assert.AreEqual(3000.00m, amount1, "Simple calculation should be correct");
            Assert.AreEqual(11262.50m, amount2, "Decimal calculation should be correct");
            Assert.AreEqual(2206.00m, amount3, "Complex decimal should be correct");
        }

        /// <summary>
        /// Test: Updating non-existent claim
        /// Expected: Should handle gracefully without throwing exception
        /// </summary>
        [TestMethod]
        public void Test_UpdateClaim_WhenClaimDoesNotExist_ShouldNotThrowException()
        {
            // Arrange
            var fakeClaim = new ClaimData
            {
                ClaimId = "C2024-999",
                LecturerEmail = "lecturer@test.com",
                Hours = 10,
                HourlyRate = 300,
                TotalAmount = 3000
            };

            // Act & Assert - Should not throw exception
            try
            {
                DataManager.UpdateClaim(fakeClaim);
                Assert.IsTrue(true, "Update should complete without exception");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Should not throw exception: {ex.Message}");
            }
        }

        /// <summary>
        /// Test: Deleting non-existent claim
        /// Expected: Should handle gracefully without throwing exception
        /// </summary>
        [TestMethod]
        public void Test_DeleteClaim_WhenClaimDoesNotExist_ShouldNotThrowException()
        {
            // Arrange
            string fakeClaimId = "C2024-999";

            // Act & Assert - Should not throw exception
            try
            {
                DataManager.DeleteClaim(fakeClaimId);
                Assert.IsTrue(true, "Delete should complete without exception");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Should not throw exception: {ex.Message}");
            }
        }

        /// <summary>
        /// Test: Bulk operations with empty list
        /// Expected: Should handle gracefully
        /// </summary>
        [TestMethod]
        public void Test_BulkOperations_WithEmptyList_ShouldHandleGracefully()
        {
            // Arrange
            var emptyClaims = new List<ClaimData>();
            var emptyIds = new List<string>();

            // Act & Assert
            try
            {
                DataManager.BulkUpdateClaims(emptyClaims);
                DataManager.BulkDeleteClaims(emptyIds);
                Assert.IsTrue(true, "Bulk operations should handle empty lists");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Should not throw exception: {ex.Message}");
            }
        }

        #endregion

        #region Performance and Integration Tests

        /// <summary>
        /// Test: Adding large number of claims
        /// Expected: System should handle volume without issues
        /// </summary>
        [TestMethod]
        public void Test_AddManyClaims_ShouldHandleLargeVolume()
        {
            // Arrange & Act
            int claimCount = 100;
            for (int i = 0; i < claimCount; i++)
            {
                DataManager.AddClaim(new ClaimData
                {
                    LecturerEmail = $"lecturer{i % 10}@test.com",
                    LecturerName = $"Dr. Lecturer {i % 10}",
                    Hours = 10 + (i % 20),
                    HourlyRate = 300 + (i % 100),
                    TotalAmount = (10 + (i % 20)) * (300 + (i % 100)),
                    Status = "Pending Review"
                });
            }

            var claims = DataManager.LoadClaims();

            // Assert
            Assert.AreEqual(claimCount, claims.Count, $"Should have {claimCount} claims");
            Assert.IsTrue(claims.All(c => c.ClaimId != null), "All claims should have IDs");
            Assert.IsTrue(claims.Select(c => c.ClaimId).Distinct().Count() == claimCount,
                "All claim IDs should be unique");
        }

        /// <summary>
        /// Test: Complete workflow - Add, Update, Retrieve, Delete
        /// Expected: All operations should work together seamlessly
        /// </summary>
        [TestMethod]
        public void Test_CompleteWorkflow_ShouldWorkEndToEnd()
        {
            // 1. Add user
            var users = new List<UserInfo>
            {
                new UserInfo
                {
                    Email = "lecturer@test.com",
                    FullName = "Dr. Smith",
                    UserType = "Lecturer",
                    IsActive = true
                }
            };
            DataManager.SaveUsers(users);

            // 2. Add claim
            var claim = new ClaimData
            {
                LecturerEmail = "lecturer@test.com",
                LecturerName = "Dr. Smith",
                Hours = 10,
                HourlyRate = 300,
                TotalAmount = 3000,
                Status = "Draft"
            };
            string claimId = DataManager.AddClaim(claim);

            // 3. Update claim
            var savedClaims = DataManager.LoadClaims();
            var savedClaim = savedClaims.First();
            savedClaim.Status = "Pending Review";
            savedClaim.Hours = 15;
            savedClaim.TotalAmount = 4500;
            DataManager.UpdateClaim(savedClaim);

            // 4. Add notification
            DataManager.CreateRejectionNotification(
                "lecturer@test.com",
                claimId,
                "Test reason",
                "Manager Name"
            );

            // 5. Retrieve and verify
            var user = DataManager.GetUser("lecturer@test.com");
            var lecturerClaims = DataManager.GetClaimsByLecturer("lecturer@test.com");
            var notifications = DataManager.GetNotificationsByUser("lecturer@test.com");

            // 6. Delete
            DataManager.DeleteClaim(claimId);
            var remainingClaims = DataManager.LoadClaims();

            // Assert
            Assert.IsNotNull(user, "User should exist");
            Assert.AreEqual(1, lecturerClaims.Count, "Should have 1 claim");
            Assert.AreEqual("Pending Review", lecturerClaims[0].Status, "Status should be updated");
            Assert.AreEqual(15, lecturerClaims[0].Hours, "Hours should be updated");
            Assert.AreEqual(1, notifications.Count, "Should have 1 notification");
            Assert.AreEqual(0, remainingClaims.Count, "Claim should be deleted");
        }

        #endregion
    }
}